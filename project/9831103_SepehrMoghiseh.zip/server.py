import threading
import socket

HEADER = 64

host = '127.0.0.1'  # localhost
port = 1373

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((host, port))
server.listen()

sport = []
crime = []
politic = []
economy = []
clients = []
addresses = []


def receive():
    while True:
        client, address = server.accept()

        message = 'Ping'.encode('ascii')
        msg_length = len(message)
        send_length = str(msg_length).encode('ascii')
        send_length += b' ' * (HEADER - len(send_length))
        client.send(send_length)
        client.send(message)

        msg_length = client.recv(HEADER).decode('ascii')
        msg_length = int(msg_length)
        pong = client.recv(msg_length).decode('ascii')

        if (pong == 'Pong'):
            print(pong)
            clients.append(client)
            addresses.append(address)
            print(f'the client connected: {str(address)}!')
            message = 'Connected to the server!'.encode('ascii')
            msg_length = len(message)
            send_length = str(msg_length).encode('ascii')
            send_length += b' ' * (HEADER - len(send_length))
            client.send(send_length)
            client.send(message)

        thread = threading.Thread(target=handle, args=(client,))
        print(clients)
        thread.start()


def handle(client):
    index = clients.index(client)
    address = addresses[index]
    while True:
        try:
            msg_length = client.recv(HEADER).decode('ascii')
            msg_length = int(msg_length)
            message = client.recv(msg_length).decode('ascii')
            command = str(message).split()[0]
            if (command == "subscribe"):
                topic = str(message).split()[1]

                if (topic == "Sport"):
                    sport.append(client)
                    print(f'{address} subscribed sport!')
                    message = 'SubAck'.encode('ascii')
                    msg_length = len(message)
                    send_length = str(msg_length).encode('ascii')
                    send_length += b' ' * (HEADER - len(send_length))
                    client.send(send_length)
                    client.send(message)

                elif (topic == "Crime"):
                    crime.append(client)
                    print(f'{address} subscribed crime!')
                    message = 'SubAck'.encode('ascii')
                    msg_length = len(message)
                    send_length = str(msg_length).encode('ascii')
                    send_length += b' ' * (HEADER - len(send_length))
                    client.send(send_length)
                    client.send(message)

                elif (topic == "Politics"):
                    politic.append(client)
                    print(f'{address} subscribed Hardware!')
                    message = 'SubAck'.encode('ascii')
                    msg_length = len(message)
                    send_length = str(msg_length).encode('ascii')
                    send_length += b' ' * (HEADER - len(send_length))
                    client.send(send_length)
                    client.send(message)

                elif (topic == "economy"):
                    economy.append(client)
                    print(f'{address} subscribed Software!')
                    message = 'SubAck'.encode('ascii')
                    msg_length = len(message)
                    send_length = str(msg_length).encode('ascii')
                    send_length += b' ' * (HEADER - len(send_length))
                    client.send(send_length)
                    client.send(message)

            elif (command == "publish"):

                topic = str(message).split()[1]
                message = message.split()[2:]
                if (topic == "Sport"):
                    message = ' '.join([str(elem) for elem in message])
                    print(f'{address} published "{message}" on Sport!')
                    message = "Sport: " + message
                    message = message.encode('ascii')
                    msg_length = len(message)
                    send_length = str(msg_length).encode('ascii')
                    send_length += b' ' * (HEADER - len(send_length))
                    for client in sport:
                        client.send(send_length)
                        client.send(message)

                elif (topic == "Crime"):
                    message = ' '.join([str(elem) for elem in message])
                    print(f'{address} published "{message}" on Crime!')
                    message = "Crime: " + message
                    message = message.encode('ascii')
                    msg_length = len(message)
                    send_length = str(msg_length).encode('ascii')
                    send_length += b' ' * (HEADER - len(send_length))
                    for client in crime:
                        client.send(send_length)
                        client.send(message)

                elif (topic == "Politics"):
                    message = ' '.join([str(elem) for elem in message])
                    print(f'{address} published "{message}" on Politics!')
                    message = "Politics: " + message
                    message = message.encode('ascii')
                    msg_length = len(message)
                    send_length = str(msg_length).encode('ascii')
                    send_length += b' ' * (HEADER - len(send_length))
                    for client in politic:
                        client.send(send_length)
                        client.send(message)

                elif (topic == "Economy"):
                    message = ' '.join([str(elem) for elem in message])
                    print(f'{address} published "{message}" on Economy!')
                    message = "Economy: " + message
                    message = message.encode('ascii')
                    msg_length = len(message)
                    send_length = str(msg_length).encode('ascii')
                    send_length += b' ' * (HEADER - len(send_length))
                    for client in economy:
                        client.send(send_length)
                        client.send(message)


        except Exception as e:
            print(e)
            clients.remove(client)
            client.close()
            addresses.remove(address)
            print(f'{address} left!')
            break


print("Server is listening...")
receive()
