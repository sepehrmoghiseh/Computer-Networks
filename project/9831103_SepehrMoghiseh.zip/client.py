import socket
import threading

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('127.0.0.1', 1373))
HEADER = 64
stop_thread = False


def receive():
    while True:
        global stop_thread
        if stop_thread:
            break
        try:
            msg_length = client.recv(HEADER).decode('ascii')
            msg_length = int(msg_length)
            message = client.recv(msg_length).decode('ascii')
            if message == "Ping":
                print(message)
                message = 'Pong'.encode('ascii')
                msg_length = len(message)
                send_length = str(msg_length).encode('ascii')
                send_length += b' ' * (HEADER - len(send_length))
                client.send(send_length)
                client.send(message)
            else:
                print(message)
        except Exception as e:
            print(e)
            client.close()
            break


def write(client):
    while True:
        if stop_thread:
            break
        inp = input("enter Publish or Subscribe and then topic\n")
        message = inp
        message = message.encode('ascii')
        msg_length = len(message)
        send_length = str(msg_length).encode('ascii')
        send_length += b' ' * (HEADER - len(send_length))
        if (inp.split()[0] == 'subscribe'):
            client.send(send_length)
            client.send(message)
        elif (inp.split()[0] == 'publish'):
            client.send(send_length)
            client.send(message)


write_thread = threading.Thread(target=write, args=(client,))
write_thread.start()
receive()
